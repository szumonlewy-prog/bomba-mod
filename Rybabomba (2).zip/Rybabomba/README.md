# Rybabomba (Fabric, Minecraft 1.21.4 – 1.21.11)

Informacyjny mod GUI: lista graczy w pobliżu, historia spotkań, ulubieni,
motywy kolorystyczne. Mod nie wysyła żadnych komend ani wiadomości do innych
graczy.

Klawisz: Right Shift (zmienisz w Sterowanie).

## Budowanie
Potrzebujesz Javy 21 i Gradle (najlepiej najnowszego) w PATH, albo zbuduj
automatycznie przez GitHub Actions (patrz `.github/workflows/build.yml`).

- Wszystkie wersje naraz: `build-all.bat` (Windows) lub `./build-all.sh` – gotowe jary lądują w `dist/`.
- Jedna wersja: `gradle clean build -Pmc=1.21.8` → `build/libs/rybabomba-1.1.0+1.21.8.jar`

Do gry wrzucasz jar odpowiadający Twojej wersji Minecrafta + Fabric Loader + Fabric API.

## Dlaczego osobny jar na wersję
W 1.21.9 Mojang zmienił obsługę myszy (klasa Click), kategorie klawiszy i pobieranie skina.
Kod zależny od wersji jest w `src/legacy` (1.21.4–1.21.8) i `src/modern` (1.21.9–1.21.11),
reszta jest wspólna w `src/main`.

## Gdy numer wersji nie pasuje
Wersje Yarn i Fabric API są w `versions/<wersja>.properties`. Jeśli Gradle nie znajdzie
któregoś numeru, wpisz aktualny z https://fabricmc.net/develop i zbuduj ponownie.

## Motywy
Zakładka Motywy ma gotowe zestawy kolorów i opcję „Własny” z kwadratem
nasycenie/jasność, suwakiem odcienia i szybką paletą. Wybrany motyw zmienia
kolor akcentu w całym GUI i zapisuje się w configu.

## Reset danych
W zakładce Profil jest przycisk resetu, który czyści ulubionych, historię
i motyw z pliku configu, po potwierdzeniu. To zwykły "wyczyść moje dane",
nie usuwanie samego moda — plik .jar zostaje w folderze mods.
