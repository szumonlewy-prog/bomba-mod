@echo off
rem Buduje Rybabomba dla wszystkich wersji 1.21.4 - 1.21.11 (wymaga Javy 21 i Gradle w PATH)
if not exist dist mkdir dist
for %%V in (1.21.4 1.21.5 1.21.6 1.21.7 1.21.8 1.21.9 1.21.10 1.21.11) do (
  echo ===== Budowanie %%V =====
  call gradle clean build -Pmc=%%V
  if errorlevel 1 (
    echo !!! BLAD dla %%V
  ) else (
    copy /Y "build\libs\rybabomba-1.1.0+%%V.jar" dist\ >nul
  )
)
echo Gotowe. Pliki .jar sa w folderze dist\
pause
