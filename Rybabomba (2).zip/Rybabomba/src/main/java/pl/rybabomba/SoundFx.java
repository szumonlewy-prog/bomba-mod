package pl.rybabomba;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.registry.Registries;
import net.minecraft.sound.SoundEvent;
import net.minecraft.util.Identifier;

/** Dźwięki GUI (wbudowane dźwięki Minecrafta). */
public final class SoundFx {
    private SoundFx() {}

    public record Opt(String name, String id) {}

    public static final Opt[] CLICKS = {
            new Opt("Click Effect", "ui.button.click"),
            new Opt("Pling", "block.note_block.pling"),
            new Opt("Bell", "block.note_block.bell"),
            new Opt("Pop", "entity.item.pickup"),
            new Opt("Brak", null)
    };

    public static void play(Opt o, double volume) {
        if (o == null || o.id() == null || volume <= 0.001) return;
        try {
            SoundEvent ev = Registries.SOUND_EVENT.get(Identifier.of("minecraft", o.id()));
            if (ev == null) return;
            MinecraftClient.getInstance().getSoundManager()
                    .play(PositionedSoundInstance.master(ev, 1.0f, (float) volume));
        } catch (Exception ignored) {
        }
    }
}
