package pl.rybabomba;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.option.KeyBinding;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;

/**
 * Rybabomba — informacyjny mod GUI: lista graczy w pobliżu, historia spotkań,
 * motywy kolorystyczne.
 * Nie wysyła żadnych wiadomości ani komend do innych graczy.
 */
public class RybabombaClient implements ClientModInitializer {

    // ---------- ustawienia wyświetlania ----------
    public static boolean showHp = true;
    public static boolean showDistance = true;
    public static boolean sortByDistance = true;
    public static int maxRange = 0; // 0 = bez limitu

    // ---------- dźwięki ----------
    public static boolean guiSounds = true;
    public static int clickSoundIdx = 0;
    public static double volume = 1.0;

    public static void guiClick() {
        if (guiSounds) SoundFx.play(SoundFx.CLICKS[clickSoundIdx], volume);
    }

    // ---------- motyw ----------
    public static String themeId = "zloty";
    public static int customColor = 0xFFFF02;

    // ---------- historia / ulubieni ----------
    public static final Map<String, Long> lastSeen = new LinkedHashMap<>();
    public static final Map<String, Long> favorites = new LinkedHashMap<>();

    private static void putNewest(Map<String, Long> map, String nick) {
        map.keySet().removeIf(k -> k.equalsIgnoreCase(nick));
        map.put(nick, System.currentTimeMillis());
        while (map.size() > 200) map.remove(map.keySet().iterator().next());
    }

    public static boolean isFavorite(String nick) {
        for (String k : favorites.keySet()) if (k.equalsIgnoreCase(nick)) return true;
        return false;
    }

    public static void toggleFavorite(String nick) {
        if (isFavorite(nick)) favorites.keySet().removeIf(k -> k.equalsIgnoreCase(nick));
        else putNewest(favorites, nick);
        save();
    }

    public static String ago(long ms) {
        long s = Math.max(0, (System.currentTimeMillis() - ms) / 1000);
        if (s < 10) return "przed chwilą";
        if (s < 60) return s + " s temu";
        if (s < 3600) return (s / 60) + " min temu";
        if (s < 86400) return (s / 3600) + " h temu";
        long d = s / 86400;
        return d == 1 ? "1 dzień temu" : d + " dni temu";
    }

    public static String date(long ms) {
        return new java.text.SimpleDateFormat("dd.MM HH:mm").format(new java.util.Date(ms));
    }

    private static String mapToString(Map<String, Long> m) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Long> e : m.entrySet()) {
            if (sb.length() > 0) sb.append(',');
            sb.append(e.getKey()).append(':').append(e.getValue());
        }
        return sb.toString();
    }

    private static void stringToMap(String str, Map<String, Long> m) {
        m.clear();
        if (str == null || str.isBlank()) return;
        for (String part : str.split(",")) {
            String[] kv = part.split(":");
            if (kv.length != 2 || !kv[0].matches("[A-Za-z0-9_]{1,16}")) continue;
            try { m.put(kv[0], Long.parseLong(kv[1])); } catch (NumberFormatException ignored) {}
        }
    }

    private static KeyBinding openKey;

    @Override
    public void onInitializeClient() {
        load();
        openKey = Compat.registerOpenKey();

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openKey.wasPressed()) {
                if (mc.currentScreen == null) mc.setScreen(new RybabombaScreen());
            }
            if (mc.world != null && mc.player != null && mc.world.getTime() % 20 == 0) {
                mc.world.getPlayers().forEach(p -> {
                    if (p == mc.player) return;
                    putNewest(lastSeen, p.getName().getString());
                });
            }
        });
    }

    // ---------- config ----------
    private static Path path() {
        return FabricLoader.getInstance().getConfigDir().resolve("rybabomba.properties");
    }

    public static void resetAll() {
        favorites.clear();
        lastSeen.clear();
        themeId = "zloty";
        save();
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("showHp", String.valueOf(showHp));
        p.setProperty("showDistance", String.valueOf(showDistance));
        p.setProperty("sortByDistance", String.valueOf(sortByDistance));
        p.setProperty("maxRange", String.valueOf(maxRange));
        p.setProperty("guiSounds", String.valueOf(guiSounds));
        p.setProperty("clickSoundIdx", String.valueOf(clickSoundIdx));
        p.setProperty("volume", String.valueOf(volume));
        p.setProperty("themeId", themeId);
        p.setProperty("customColor", String.valueOf(customColor));
        p.setProperty("favorites", mapToString(favorites));
        try (Writer w = Files.newBufferedWriter(path(), StandardCharsets.UTF_8)) {
            p.store(w, "Rybabomba");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void load() {
        Path f = path();
        if (!Files.exists(f)) return;
        Properties p = new Properties();
        try (Reader r = Files.newBufferedReader(f, StandardCharsets.UTF_8)) {
            p.load(r);
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }
        showHp = Boolean.parseBoolean(p.getProperty("showHp", "true"));
        showDistance = Boolean.parseBoolean(p.getProperty("showDistance", "true"));
        sortByDistance = Boolean.parseBoolean(p.getProperty("sortByDistance", "true"));
        try { maxRange = Integer.parseInt(p.getProperty("maxRange", "0")); } catch (NumberFormatException ignored) {}
        guiSounds = Boolean.parseBoolean(p.getProperty("guiSounds", "true"));
        try {
            clickSoundIdx = Math.max(0, Math.min(SoundFx.CLICKS.length - 1, Integer.parseInt(p.getProperty("clickSoundIdx", "0"))));
            volume = Math.max(0.0, Math.min(1.0, Double.parseDouble(p.getProperty("volume", "1.0"))));
            customColor = Integer.parseInt(p.getProperty("customColor", String.valueOf(0xFFFF02)));
        } catch (NumberFormatException ignored) {}
        themeId = p.getProperty("themeId", "zloty");
        stringToMap(p.getProperty("favorites", ""), favorites);
    }
}
