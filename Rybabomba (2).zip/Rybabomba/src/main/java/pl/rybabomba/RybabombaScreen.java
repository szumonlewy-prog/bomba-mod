package pl.rybabomba;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

import java.util.*;
import java.util.function.*;

public class RybabombaScreen extends ScreenBase {
    private static final int PW = 460, PH = 290, SIDE = 100;
    private static final int BG = 0xF0101512;
    private static final int DARK = 0xFF14241C;
    private static final int CARD = 0xFF0E1814;
    private static final int TEXT = 0xFFE8F2EC;
    private static final int MUTED = 0xFF8FA89A;

    private static int accent() { return 0xFF000000 | Themes.accent(); }
    private static int accentDim() {
        int c = Themes.accent();
        int r = ((c >> 16) & 0xFF) / 3, g = ((c >> 8) & 0xFF) / 3, b = (c & 0xFF) / 3;
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    private enum Tab { GRACZE("Gracze"), HISTORIA("Historia"), MOTYWY("Motywy"), USTAWIENIA("Ustawienia"), PROFIL("Profil");
        final String label;
        Tab(String l) { label = l; }
    }

    private record Hit(int x, int y, int w, int h, Runnable action) {}

    private final List<Hit> hits = new ArrayList<>();
    private Tab tab = Tab.GRACZE;
    private TextFieldWidget search;
    private int scroll = 0, maxScroll = 0;
    private int px, py, mouseX, mouseY;
    private String message = "";
    private long messageUntil = 0;

    // Motywy: edycja koloru własnego
    private boolean editingCustom = false;
    private float hue, sat = 1f, val = 1f;
    private int dragMode = 0; // 1 = kwadrat SV, 2 = suwak HUE

    // Profil: potwierdzenie resetu
    private boolean confirmReset = false;

    public RybabombaScreen() {
        super(Text.literal("Rybabomba"));
    }

    @Override
    protected void init() {
        px = (width - PW) / 2;
        py = (height - PH) / 2;
        int fw = PW - SIDE - 30;

        search = new TextFieldWidget(textRenderer, px + SIDE + 40, py + 12, 220, 14, Text.empty());
        search.setPlaceholder(Text.literal("Wyszukaj gracza..."));
        search.setMaxLength(24);
        search.setChangedListener(t -> scroll = 0);
        addDrawableChild(search);

        updateVisibility();
    }

    private void updateVisibility() {
        search.setVisible(tab == Tab.GRACZE || tab == Tab.HISTORIA);
    }

    private void toast(String m) {
        message = m;
        messageUntil = System.currentTimeMillis() + 3000;
    }

    private boolean over(int x, int y, int w, int h) {
        return mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
    }

    private void button(DrawContext ctx, int x, int y, int w, int h, String label, Runnable action) {
        boolean hov = over(x, y, w, h);
        ctx.fill(x, y, x + w, y + h, hov ? accentDim() : CARD);
        ctx.drawBorder(x, y, w, h, accent());
        ctx.drawText(textRenderer, label, x + (w - textRenderer.getWidth(label)) / 2, y + (h - 8) / 2, TEXT, false);
        hits.add(new Hit(x, y, w, h, action));
    }

    private static String fmt(float v) {
        return String.format(Locale.US, "%.1f", v).replace('.', ',') + "m";
    }

    // ---------------- render ----------------
    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        mouseX = mx;
        mouseY = my;
        hits.clear();

        ctx.fill(0, 0, width, height, 0x99000000);
        ctx.fill(px, py, px + PW, py + PH, BG);
        ctx.drawBorder(px, py, PW, PH, accent());

        ctx.drawText(textRenderer, "><> Rybabomba", px + 10, py + 12, accent(), true);
        ctx.fill(px + SIDE, py + 8, px + SIDE + 1, py + PH - 8, DARK);
        Tab[] tabs = Tab.values();
        for (int i = 0; i < tabs.length; i++) {
            final Tab t = tabs[i];
            int x = px + 8, y = py + 34 + i * 24;
            boolean sel = t == tab;
            ctx.fill(x, y, x + 84, y + 18, sel ? accentDim() : 0xFF0B1410);
            ctx.drawBorder(x, y, 84, 18, sel ? accent() : DARK);
            ctx.drawText(textRenderer, t.label, x + 6, y + 5, sel ? TEXT : MUTED, false);
            hits.add(new Hit(x, y, 84, 18, () -> {
                tab = t;
                scroll = 0;
                editingCustom = false;
                confirmReset = false;
                search.setText("");
                updateVisibility();
            }));
        }
        ctx.drawText(textRenderer, "1.2", px + 10, py + PH - 14, MUTED, false);

        int lx = px + SIDE + 10, ly = py + 40;
        switch (tab) {
            case GRACZE -> drawPlayers(ctx, lx, ly);
            case HISTORIA -> drawHistory(ctx, lx, ly);
            case MOTYWY -> drawThemes(ctx, lx, ly);
            case USTAWIENIA -> drawSettings(ctx, lx, ly);
            case PROFIL -> drawProfile(ctx, lx, ly);
        }

        if (System.currentTimeMillis() < messageUntil) {
            ctx.drawText(textRenderer, message, lx, py + PH - 14, accent(), false);
        }
    }

    // ---------------- Gracze ----------------
    private List<AbstractClientPlayerEntity> players() {
        if (client == null || client.world == null || client.player == null) return List.of();
        String q = search.getText().toLowerCase();
        List<AbstractClientPlayerEntity> list = new ArrayList<>();
        for (AbstractClientPlayerEntity p : client.world.getPlayers()) {
            if (p == client.player) continue;
            if (!p.getName().getString().toLowerCase().contains(q)) continue;
            float d = client.player.distanceTo(p);
            if (RybabombaClient.maxRange > 0 && d > RybabombaClient.maxRange) continue;
            list.add(p);
        }
        if (RybabombaClient.sortByDistance) list.sort(Comparator.comparingDouble(p -> client.player.distanceTo(p)));
        return list;
    }

    private void drawPlayers(DrawContext ctx, int lx, int ly) {
        List<AbstractClientPlayerEntity> list = players();
        int cw = (PW - SIDE - 30 - 8) / 2, ch = 44, gap = 6;
        int visibleRows = (PH - 50) / (ch + gap);
        maxScroll = Math.max(0, (list.size() + 1) / 2 - visibleRows);
        scroll = MathHelper.clamp(scroll, 0, maxScroll);

        if (list.isEmpty()) {
            ctx.drawText(textRenderer, "Brak graczy w pobliżu.", lx, ly + 4, MUTED, false);
            return;
        }

        ctx.enableScissor(lx - 1, ly - 1, lx + 2 * cw + 10, ly + visibleRows * (ch + gap));
        for (int i = scroll * 2; i < list.size() && i < (scroll + visibleRows) * 2; i++) {
            AbstractClientPlayerEntity p = list.get(i);
            String name = p.getName().getString();
            int col = i % 2, row = i / 2 - scroll;
            int x = lx + col * (cw + 8), y = ly + row * (ch + gap);
            boolean fav = RybabombaClient.isFavorite(name);

            boolean hov = over(x, y, cw, ch);
            ctx.fill(x, y, x + cw, y + ch, hov ? accentDim() : CARD);
            ctx.drawBorder(x, y, cw, ch, fav ? accent() : DARK);
            Compat.drawHead(ctx, p, x + 5, y + 6, 32);

            ctx.drawText(textRenderer, name, x + 44, y + 6, TEXT, false);
            int ty = y + 18;
            if (RybabombaClient.showHp) {
                ctx.drawText(textRenderer, "HP: " + (int) p.getHealth() + "/" + (int) p.getMaxHealth(), x + 44, ty, accent(), false);
                ty += 11;
            }
            if (RybabombaClient.showDistance) {
                ctx.drawText(textRenderer, "Dystans: " + fmt(client.player.distanceTo(p)), x + 44, ty, accent(), false);
            }
            final String nm = name;
            hits.add(new Hit(x + cw - 20, y + 4, 16, 16, () -> { RybabombaClient.toggleFavorite(nm); RybabombaClient.guiClick(); }));
            ctx.drawText(textRenderer, fav ? "*" : "+", x + cw - 16, y + 5, fav ? accent() : MUTED, true);
        }
        ctx.disableScissor();
    }

    // ---------------- Historia ----------------
    private int histTab = 0; // 0 widziani, 1 ulubieni
    private record Row(String nick, long time) {}

    private void drawHistory(DrawContext ctx, int lx, int ly) {
        int w = PW - SIDE - 30;
        String[] names = {"Widziani", "Ulubieni"};
        int tw = 110, gx = 6;
        int sx = lx;
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            int x = sx + i * (tw + gx);
            boolean sel = histTab == i;
            ctx.fill(x, ly, x + tw, ly + 16, sel ? accentDim() : CARD);
            ctx.drawBorder(x, ly, tw, 16, sel ? accent() : DARK);
            ctx.drawText(textRenderer, names[i], x + (tw - textRenderer.getWidth(names[i])) / 2, ly + 4, sel ? TEXT : MUTED, false);
            hits.add(new Hit(x, ly, tw, 16, () -> { histTab = idx; scroll = 0; }));
        }

        Map<String, Long> src = histTab == 0 ? RybabombaClient.lastSeen : RybabombaClient.favorites;
        List<Row> rows = new ArrayList<>();
        String q = search.getText().trim().toLowerCase();
        for (Map.Entry<String, Long> e : src.entrySet())
            if (e.getKey().toLowerCase().contains(q)) rows.add(new Row(e.getKey(), e.getValue()));
        Collections.reverse(rows);

        int top = ly + 24, rh = 30, gap = 4;
        int visible = (PH - 50 - 24) / (rh + gap);
        maxScroll = Math.max(0, rows.size() - visible);
        scroll = MathHelper.clamp(scroll, 0, maxScroll);

        if (rows.isEmpty()) {
            ctx.drawText(textRenderer, "Brak wyników.", lx, top + 6, MUTED, false);
            return;
        }

        ctx.enableScissor(lx - 1, top - 1, lx + w + 1, top + visible * (rh + gap));
        for (int i = scroll; i < rows.size() && i < scroll + visible; i++) {
            final Row r = rows.get(i);
            int y = top + (i - scroll) * (rh + gap);
            boolean hov = over(lx, y, w, rh);
            ctx.fill(lx, y, lx + w, y + rh, hov ? accentDim() : CARD);
            ctx.drawBorder(lx, y, w, rh, DARK);
            ctx.drawText(textRenderer, (i + 1) + ". " + r.nick(), lx + 8, y + 5, TEXT, true);
            ctx.drawText(textRenderer, RybabombaClient.ago(r.time()) + "  ·  " + RybabombaClient.date(r.time()),
                    lx + 8, y + 17, MUTED, false);
            boolean fav = RybabombaClient.isFavorite(r.nick());
            button(ctx, lx + w - 98, y + 7, 90, 16, fav ? "- Ulubieni" : "+ Ulubieni",
                    () -> { RybabombaClient.toggleFavorite(r.nick()); RybabombaClient.guiClick(); });
        }
        ctx.disableScissor();
    }

    // ---------------- Motywy ----------------
    private void drawThemes(DrawContext ctx, int lx, int ly) {
        if (editingCustom) { drawCustomEditor(ctx, lx, ly); return; }

        Themes.Theme[] all = Themes.ALL;
        int cols = 2, cw = (PW - SIDE - 30 - 8) / cols, ch = 26, gap = 6;
        int n = all.length + 1; // + Własny
        for (int i = 0; i < n; i++) {
            int col = i % cols, row = i / cols;
            int x = lx + col * (cw + 8), y = ly + row * (ch + gap);
            boolean isCustom = i == all.length;
            String id = isCustom ? "wlasny" : all[i].id();
            String name = isCustom ? "Własny" : all[i].name();
            int color = isCustom ? (0xFF000000 | RybabombaClient.customColor) : (0xFF000000 | all[i].color());
            boolean active = id.equals(RybabombaClient.themeId);
            boolean hov = over(x, y, cw, ch);

            ctx.fill(x, y, x + cw, y + ch, hov ? DARK : CARD);
            ctx.drawBorder(x, y, cw, ch, active ? accent() : DARK);
            ctx.fill(x + 6, y + 8, x + 16, y + 18, color);
            ctx.drawBorder(x + 6, y + 8, 10, 10, 0xFF000000);
            ctx.drawText(textRenderer, name, x + 22, y + 5, TEXT, false);
            ctx.drawText(textRenderer, active ? "ACTIVE" : (isCustom ? "Kliknij, aby edytować" : "Kliknij, aby wybrać"),
                    x + 22, y + 15, active ? accent() : MUTED, false);

            hits.add(new Hit(x, y, cw, ch, () -> {
                if (isCustom) {
                    RybabombaClient.themeId = "wlasny";
                    int c = RybabombaClient.customColor;
                    float[] hsv = java.awt.Color.RGBtoHSB((c >> 16) & 0xFF, (c >> 8) & 0xFF, c & 0xFF, null);
                    hue = hsv[0]; sat = hsv[1]; val = hsv[2];
                    editingCustom = true;
                } else {
                    RybabombaClient.themeId = id;
                }
                RybabombaClient.guiClick();
                RybabombaClient.save();
            }));
        }
    }

    private static final int[] QUICK_PALETTE = {
            0x22E05A, 0x4FD6E8, 0xE02B2B, 0x9B3FE0, 0xFFB300, 0x2458C9, 0xFF7FAE, 0xCFCFCF
    };

    private void drawCustomEditor(DrawContext ctx, int lx, int ly) {
        button(ctx, lx, ly, 60, 16, "< Wróć", () -> editingCustom = false);

        int sq = 110;
        int sx = lx, sy = ly + 24;
        // kwadrat nasycenie/jasność
        for (int yy = 0; yy < sq; yy += 2) {
            float v = 1f - yy / (float) sq;
            int left = java.awt.Color.HSBtoRGB(hue, 0f, v);
            int right = java.awt.Color.HSBtoRGB(hue, 1f, v);
            // prosty poziomy gradient co 2 piksele
            for (int xx = 0; xx < sq; xx += 2) {
                float s = xx / (float) sq;
                int c = java.awt.Color.HSBtoRGB(hue, s, v);
                ctx.fill(sx + xx, sy + yy, sx + xx + 2, sy + yy + 2, 0xFF000000 | (c & 0xFFFFFF));
            }
        }
        ctx.drawBorder(sx, sy, sq, sq, 0xFF000000);
        int mkx = sx + (int) (sat * sq), mky = sy + (int) ((1 - val) * sq);
        ctx.drawBorder(mkx - 3, mky - 3, 6, 6, 0xFFFFFFFF);
        hits.add(new Hit(sx, sy, sq, sq, () -> dragMode = 1));

        // pionowy suwak HUE
        int hx = sx + sq + 14, hy = sy, hh = sq, hw = 14;
        for (int yy = 0; yy < hh; yy++) {
            float h = yy / (float) hh;
            int c = java.awt.Color.HSBtoRGB(h, 1f, 1f);
            ctx.fill(hx, hy + yy, hx + hw, hy + yy + 1, 0xFF000000 | (c & 0xFFFFFF));
        }
        ctx.drawBorder(hx, hy, hw, hh, 0xFF000000);
        int hm = hy + (int) (hue * hh);
        ctx.fill(hx - 2, hm - 1, hx + hw + 2, hm + 1, 0xFFFFFFFF);
        hits.add(new Hit(hx - 2, hy, hw + 4, hh, () -> dragMode = 2));

        int pcx = hx + hw + 24;
        int rgb = java.awt.Color.HSBtoRGB(hue, sat, val) & 0xFFFFFF;
        ctx.fill(pcx, sy, pcx + 26, sy + 26, 0xFF000000 | rgb);
        ctx.drawBorder(pcx, sy, 26, 26, 0xFF000000);
        ctx.drawText(textRenderer, "WŁASNY MOTYW", pcx + 32, sy + 2, TEXT, true);
        ctx.drawText(textRenderer, String.format("#%06X", rgb), pcx + 32, sy + 13, accent(), false);

        ctx.drawText(textRenderer, "Szybka paleta:", pcx, sy + 34, MUTED, false);
        for (int i = 0; i < QUICK_PALETTE.length; i++) {
            int px2 = pcx + (i % 4) * 22, py2 = sy + 46 + (i / 4) * 22;
            int col = QUICK_PALETTE[i];
            ctx.fill(px2, py2, px2 + 18, py2 + 18, 0xFF000000 | col);
            ctx.drawBorder(px2, py2, 18, 18, 0xFF000000);
            hits.add(new Hit(px2, py2, 18, 18, () -> {
                float[] hsv = java.awt.Color.RGBtoHSB((col >> 16) & 0xFF, (col >> 8) & 0xFF, col & 0xFF, null);
                hue = hsv[0]; sat = hsv[1]; val = hsv[2];
                applyCustomColor();
            }));
        }

        button(ctx, lx, sy + sq + 10, 140, 18, "Zapisz jako motyw", () -> { applyCustomColor(); toast("Zapisano własny motyw"); });
    }

    private void applyCustomColor() {
        int rgb = java.awt.Color.HSBtoRGB(hue, sat, val) & 0xFFFFFF;
        RybabombaClient.customColor = rgb;
        RybabombaClient.themeId = "wlasny";
        RybabombaClient.save();
    }

    @Override
    protected boolean handleDrag(double mx, double my) {
        if (tab == Tab.MOTYWY && editingCustom && dragMode != 0) {
            int sq = 110;
            int sx = px + SIDE + 10, sy = py + 40 + 24;
            if (dragMode == 1) {
                sat = MathHelper.clamp((float) (mx - sx) / sq, 0f, 1f);
                val = 1f - MathHelper.clamp((float) (my - sy) / sq, 0f, 1f);
            } else {
                int hy = sy, hh = sq;
                hue = MathHelper.clamp((float) (my - hy) / hh, 0f, 1f);
            }
            applyCustomColor();
            return true;
        }
        if (dragItem != null) { applySlider(mx); return true; }
        return false;
    }

    @Override
    protected void handleRelease() {
        dragMode = 0;
        if (dragItem != null) { dragItem = null; RybabombaClient.save(); }
    }

    // ---------------- Ustawienia ----------------
    private record Item(String icon, String title, String desc, int kind, BooleanSupplier on, Supplier<String> val,
                        Runnable prev, Runnable next, DoubleSupplier frac, DoubleConsumer setFrac) {}
    private record Section(String title, List<Item> items) {}

    private static final int[] RANGES = {0, 32, 64, 128};
    private Item dragItem;
    private double dragBarX, dragBarW, clickX;

    private static Item tog(String icon, String t, String d, BooleanSupplier on, Runnable toggle) {
        return new Item(icon, t, d, 0, on, null, toggle, null, null, null);
    }
    private static Item sel(String icon, String t, String d, Supplier<String> val, Runnable prev, Runnable next) {
        return new Item(icon, t, d, 1, null, val, prev, next, null, null);
    }
    private static Item sld(String icon, String t, String d, DoubleSupplier f, DoubleConsumer set) {
        return new Item(icon, t, d, 2, null, null, null, null, f, set);
    }
    private static int step(int[] vals, int cur, int dir) {
        int i = 0;
        for (int k = 0; k < vals.length; k++) if (vals[k] == cur) i = k;
        return vals[(i + dir + vals.length) % vals.length];
    }
    private void changeClickSound(int dir) {
        int n = SoundFx.CLICKS.length;
        RybabombaClient.clickSoundIdx = (RybabombaClient.clickSoundIdx + dir + n) % n;
        SoundFx.play(SoundFx.CLICKS[RybabombaClient.clickSoundIdx], RybabombaClient.volume);
        RybabombaClient.save();
    }

    private List<Section> buildSettings() {
        List<Section> out = new ArrayList<>();
        List<Item> audio = new ArrayList<>();
        audio.add(tog("GUI", "Dźwięki GUI", "Klik w menu", () -> RybabombaClient.guiSounds,
                () -> { RybabombaClient.guiSounds = !RybabombaClient.guiSounds; RybabombaClient.save(); }));
        audio.add(sel("CL", "Dźwięk kliknięcia", "Brzmienie przycisków",
                () -> SoundFx.CLICKS[RybabombaClient.clickSoundIdx].name(),
                () -> changeClickSound(-1), () -> changeClickSound(1)));
        audio.add(sld("VOL", "Głośność dźwięków", "Poziom głośności",
                () -> RybabombaClient.volume, v -> RybabombaClient.volume = v));
        out.add(new Section("DŹWIĘKI I AUDIO", audio));

        List<Item> list = new ArrayList<>();
        list.add(tog("HP", "Pokaż HP", "Zdrowie gracza", () -> RybabombaClient.showHp,
                () -> { RybabombaClient.showHp = !RybabombaClient.showHp; RybabombaClient.save(); }));
        list.add(tog("m", "Pokaż dystans", "Metry od ciebie", () -> RybabombaClient.showDistance,
                () -> { RybabombaClient.showDistance = !RybabombaClient.showDistance; RybabombaClient.save(); }));
        list.add(tog("S", "Sortowanie", "Po dystansie", () -> RybabombaClient.sortByDistance,
                () -> { RybabombaClient.sortByDistance = !RybabombaClient.sortByDistance; RybabombaClient.save(); }));
        list.add(sel("R", "Maks. zasięg", "Limit listy graczy",
                () -> RybabombaClient.maxRange == 0 ? "bez limitu" : RybabombaClient.maxRange + "m",
                () -> { RybabombaClient.maxRange = step(RANGES, RybabombaClient.maxRange, -1); RybabombaClient.save(); },
                () -> { RybabombaClient.maxRange = step(RANGES, RybabombaClient.maxRange, 1); RybabombaClient.save(); }));
        out.add(new Section("LISTA GRACZY", list));
        return out;
    }

    private static String optionsLabel(int n) {
        if (n == 1) return "1 OPCJA";
        if (n >= 2 && n <= 4) return n + " OPCJE";
        return n + " OPCJI";
    }

    private void clippedHit(int x, int y, int w, int h, int ly, int areaH, Runnable action) {
        int top = Math.max(y, ly), bottom = Math.min(y + h, ly + areaH);
        if (bottom > top) hits.add(new Hit(x, top, w, bottom - top, action));
    }

    private void drawSettings(DrawContext ctx, int lx, int ly) {
        int w = PW - SIDE - 30;
        int areaH = PH - 50;
        String q = search.getText().trim().toLowerCase();
        int colW = (w - 8) / 2;
        int top = ly - scroll * 20;
        int y = top;
        boolean any = false;

        ctx.enableScissor(lx - 1, ly - 1, lx + w + 1, ly + areaH);
        for (Section sec : buildSettings()) {
            List<Item> items = new ArrayList<>();
            for (Item it : sec.items())
                if (q.isEmpty() || it.title().toLowerCase().contains(q) || it.desc().toLowerCase().contains(q)) items.add(it);
            if (items.isEmpty()) continue;
            any = true;

            ctx.drawText(textRenderer, sec.title(), lx + 2, y + 3, TEXT, false);
            String tagTxt = optionsLabel(items.size());
            int tgw = textRenderer.getWidth(tagTxt) + 10;
            ctx.fill(lx + w - tgw, y, lx + w, y + 13, DARK);
            ctx.drawText(textRenderer, tagTxt, lx + w - tgw + 5, y + 3, accent(), false);
            y += 19;

            int col = 0, rowH = 0;
            for (Item it : items) {
                boolean full = it.kind() == 2;
                if (full && col != 0) { y += rowH + 6; col = 0; rowH = 0; }
                int h = full ? 40 : 34;
                int x = lx + (full ? 0 : col * (colW + 8));
                int cw = full ? w : colW;
                drawItem(ctx, it, x, y, cw, h, ly, areaH);
                if (full) y += h + 6;
                else { rowH = Math.max(rowH, h); if (++col == 2) { y += rowH + 6; col = 0; rowH = 0; } }
            }
            if (col != 0) y += rowH + 6;
            y += 6;
        }
        if (!any) ctx.drawText(textRenderer, "Brak wyników.", lx, ly + 4, MUTED, false);
        ctx.disableScissor();

        int total = y - top;
        maxScroll = Math.max(0, (total - areaH + 19) / 20);
        scroll = MathHelper.clamp(scroll, 0, maxScroll);
    }

    private void drawItem(DrawContext ctx, Item it, int x, int y, int cw, int h, int ly, int areaH) {
        boolean hov = over(x, y, cw, h) && mouseY >= ly && mouseY < ly + areaH;
        boolean on = it.kind() == 0 && it.on().getAsBoolean();
        ctx.fill(x, y, x + cw, y + h, hov ? DARK : CARD);
        ctx.drawBorder(x, y, cw, h, on ? accent() : DARK);

        int ix = x + 6, iy = y + (h - 20) / 2;
        ctx.fill(ix, iy, ix + 20, iy + 20, DARK);
        ctx.drawBorder(ix, iy, 20, 20, accent());
        ctx.drawText(textRenderer, it.icon(), ix + 10 - textRenderer.getWidth(it.icon()) / 2, iy + 6, TEXT, false);

        int tx = x + 32;
        if (it.kind() == 0) {
            int room = cw - 32 - 40;
            ctx.drawText(textRenderer, textRenderer.trimToWidth(it.title(), room), tx, y + 8, TEXT, true);
            ctx.drawText(textRenderer, textRenderer.trimToWidth(it.desc(), room), tx, y + 20, MUTED, false);
            int sxp = x + cw - 34, syp = y + (h - 12) / 2;
            ctx.fill(sxp, syp, sxp + 26, syp + 12, on ? accent() : 0xFF3A4A40);
            int kx = on ? sxp + 14 : sxp + 2;
            ctx.fill(kx, syp + 2, kx + 10, syp + 10, 0xFFFFFFFF);
            clippedHit(x, y, cw, h, ly, areaH, it.prev());
        } else if (it.kind() == 1) {
            ctx.drawText(textRenderer, textRenderer.trimToWidth(it.title(), cw - 38), tx, y + 5, TEXT, true);
            int vx0 = tx, vx1 = x + cw - 6;
            ctx.fill(vx0, y + 18, vx1, y + 30, 0xFF0A140E);
            ctx.drawText(textRenderer, "<", vx0 + 3, y + 20, accent(), false);
            ctx.drawText(textRenderer, ">", vx1 - 8, y + 20, accent(), false);
            String v = textRenderer.trimToWidth(it.val().get(), vx1 - vx0 - 26);
            ctx.drawText(textRenderer, v, (vx0 + vx1) / 2 - textRenderer.getWidth(v) / 2, y + 20, TEXT, false);
            clippedHit(vx0, y + 16, 18, 16, ly, areaH, it.prev());
            clippedHit(vx1 - 18, y + 16, 18, 16, ly, areaH, it.next());
        } else {
            double f = MathHelper.clamp(it.frac().getAsDouble(), 0.0, 1.0);
            ctx.drawText(textRenderer, it.title(), tx, y + 6, TEXT, true);
            ctx.drawText(textRenderer, it.desc(), tx, y + 17, MUTED, false);
            String pct = Math.round(f * 100) + "%";
            ctx.drawText(textRenderer, pct, x + cw - 8 - textRenderer.getWidth(pct), y + 6, accent(), false);
            int barX = tx, barW = cw - 32 - 10, barY = y + h - 9;
            ctx.fill(barX, barY, barX + barW, barY + 4, 0xFF0A140E);
            ctx.fill(barX, barY, barX + (int) (barW * f), barY + 4, accent());
            int kx = barX + (int) (barW * f) - 3;
            ctx.fill(kx, barY - 2, kx + 6, barY + 6, 0xFFFFFFFF);
            final Item item = it;
            final int fbx = barX, fbw = barW;
            clippedHit(barX - 4, barY - 5, barW + 8, 14, ly, areaH, () -> {
                dragItem = item; dragBarX = fbx; dragBarW = fbw; applySlider(clickX);
            });
        }
    }

    private void applySlider(double mx) {
        if (dragItem == null) return;
        dragItem.setFrac().accept(MathHelper.clamp((mx - dragBarX) / dragBarW, 0.0, 1.0));
    }

    // ---------------- Profil ----------------
    private void drawProfile(DrawContext ctx, int lx, int ly) {
        int w = PW - SIDE - 30;

        ctx.fill(lx, ly, lx + w, ly + 70, CARD);
        ctx.drawBorder(lx, ly, w, 70, accent());
        ctx.drawText(textRenderer, "O MODZIE", lx + 8, ly + 6, TEXT, true);
        ctx.drawText(textRenderer, "Rybabomba — informacyjny GUI: lista graczy, historia,", lx + 8, ly + 20, MUTED, false);
        ctx.drawText(textRenderer, "ulubieni i motywy kolorystyczne.", lx + 8, ly + 31, MUTED, false);
        ctx.drawText(textRenderer, "Widzianych graczy: " + RybabombaClient.lastSeen.size()
                + "   Ulubionych: " + RybabombaClient.favorites.size(), lx + 8, ly + 48, accent(), false);

        int ry = ly + 86;
        ctx.fill(lx, ry, lx + w, ry + 60, CARD);
        ctx.drawBorder(lx, ry, w, 60, 0xFFE06060);
        ctx.drawText(textRenderer, "RESET DANYCH MODA", lx + 8, ry + 6, TEXT, true);
        ctx.drawText(textRenderer, "Usuwa ulubionych, historię i motyw z tego pliku.", lx + 8, ry + 18, MUTED, false);

        if (!confirmReset) {
            button(ctx, lx + 8, ry + 34, 160, 18, "Resetuj wszystko", () -> { confirmReset = true; updateVisibility(); });
        } else {
            ctx.drawText(textRenderer, "Na pewno? Tego nie da się cofnąć.", lx + 8, ry + 34, 0xFFE06060, false);
            button(ctx, lx + 8, ry + 46, 90, 16, "Tak, usuń", () -> {
                RybabombaClient.resetAll();
                confirmReset = false;
                updateVisibility();
                toast("Zresetowano dane moda");
            });
            button(ctx, lx + 102, ry + 46, 90, 16, "Anuluj", () -> { confirmReset = false; updateVisibility(); });
        }
    }

    // ---------------- input ----------------
    @Override
    protected boolean handleClick(double mx, double my, int button) {
        if (button == 0) {
            for (Hit h : new ArrayList<>(hits)) {
                if (mx >= h.x() && mx < h.x() + h.w() && my >= h.y() && my < h.y() + h.h()) {
                    clickX = mx;
                    RybabombaClient.guiClick();
                    h.action().run();
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        if (tab != Tab.MOTYWY || !editingCustom) {
            scroll = MathHelper.clamp(scroll - (int) Math.signum(v), 0, maxScroll);
            return true;
        }
        return super.mouseScrolled(mx, my, h, v);
    }

    @Override
    public void removed() {
        RybabombaClient.save();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
