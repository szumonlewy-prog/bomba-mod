package pl.rybabomba;

import java.util.LinkedHashMap;
import java.util.Map;

public final class Themes {
    private Themes() {}

    public record Theme(String id, String name, int color) {}

    public static final Theme[] ALL = {
            new Theme("zloty", "Złoty", 0xE0B000),
            new Theme("neon_cyberpunk", "Neon Cyberpunk", 0xFF2FD1),
            new Theme("vaporwave", "Vaporwave", 0xB36BFF),
            new Theme("matrix_green", "Matrix Green", 0x22E05A),
            new Theme("ice_crystal", "Ice Crystal", 0x4FD6E8),
            new Theme("blood_moon", "Blood Moon", 0xE02B2B),
            new Theme("amethyst_void", "Amethyst Void", 0x9B3FE0),
            new Theme("sunset_horizon", "Sunset Horizon", 0xFF7A33),
            new Theme("midnight_ocean", "Midnight Ocean", 0x2458C9),
            new Theme("sakura", "Sakura", 0xFF7FAE),
            new Theme("electric_lime", "Electric Lime", 0xC6FF2E),
            new Theme("nordic_teal", "Nordic Teal", 0x2EB6A3),
            new Theme("monochrome", "Monochrome", 0xCFCFCF),
            new Theme("cosmic_nebula", "Cosmic Nebula", 0x7A5CFF),
            new Theme("solar_flare", "Solar Flare", 0xFFB300),
    };

    private static final Map<String, Theme> BY_ID = new LinkedHashMap<>();
    static {
        for (Theme t : ALL) BY_ID.put(t.id(), t);
    }

    /** Aktualny kolor akcentu (bez kanału alfa), uwzględnia "Własny". */
    public static int accent() {
        if ("wlasny".equals(RybabombaClient.themeId)) return RybabombaClient.customColor & 0xFFFFFF;
        Theme t = BY_ID.get(RybabombaClient.themeId);
        return t != null ? t.color() : ALL[0].color();
    }
}
