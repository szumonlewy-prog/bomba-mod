package pl.rybabomba;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/** Bazowy ekran: Minecraft 1.21.9 - 1.21.11 (mouseClicked z obiektem Click). */
public abstract class ScreenBase extends Screen {
    protected ScreenBase(Text title) {
        super(title);
    }

    protected abstract boolean handleClick(double mx, double my, int button);

    protected boolean handleDrag(double mx, double my) { return false; }

    protected void handleRelease() {}

    @Override
    public boolean mouseDragged(Click click, double dx, double dy) {
        if (handleDrag(click.x(), click.y())) return true;
        return super.mouseDragged(click, dx, dy);
    }

    @Override
    public boolean mouseReleased(Click click) {
        handleRelease();
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (handleClick(click.x(), click.y(), click.button())) return true;
        return super.mouseClicked(click, doubled);
    }
}
