package pl.rybabomba;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/** Bazowy ekran: Minecraft 1.21.4 - 1.21.8 (mouseClicked z double/double/int). */
public abstract class ScreenBase extends Screen {
    protected ScreenBase(Text title) {
        super(title);
    }

    protected abstract boolean handleClick(double mx, double my, int button);

    protected boolean handleDrag(double mx, double my) { return false; }

    protected void handleRelease() {}

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (handleDrag(mx, my)) return true;
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        handleRelease();
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (handleClick(mx, my, button)) return true;
        return super.mouseClicked(mx, my, button);
    }
}
