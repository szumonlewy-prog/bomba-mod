package pl.rybabomba;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/** Kod zależny od wersji: Minecraft 1.21.4 - 1.21.8. */
public final class Compat {
    private Compat() {}

    public static KeyBinding registerOpenKey() {
        return KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.rybabomba.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.rybabomba"));
    }

    public static void drawHead(DrawContext ctx, AbstractClientPlayerEntity p, int x, int y, int size) {
        PlayerSkinDrawer.draw(ctx, p.getSkinTextures(), x, y, size);
    }
}
